docker build ./ --no-cache=true -t music-suggest-server
